#include <algorithm>
#include <chrono>
#include <iostream>
#include<vector>
using namespace std;
using namespace std::chrono;

int main() {
   int arr[80000] = {};


    // for (int j = 0; j<20000;j++)
    //         arr[j] = j;

   int *ptr = &arr[0];
   cout<<"The values in the array are: ";
    int i = 0; 

    int size = sizeof(int);


   while(i < 80000) 
   {
    auto start = high_resolution_clock::now();
      cout<< *ptr << " ";
       
    auto middle = high_resolution_clock::now();

      *ptr = *ptr + 2000;

      cout<< *ptr <<" "<< size << " ";
    auto end = high_resolution_clock::now();


    i=i+2000;


    auto duration1 = duration_cast<milliseconds>(middle - start);

        //cout << "size " << size<< endl;
        size = size + (2000* sizeof(int));


    auto duration = duration_cast<milliseconds>(end - middle);
 
    cout << duration1.count() <<" "<< duration.count() << " seconds" << endl;


   }
   return 0;
}