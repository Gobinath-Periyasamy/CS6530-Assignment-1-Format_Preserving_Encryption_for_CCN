#include <algorithm>
#include <chrono>
#include <iostream>
#include<vector>
using namespace std;
using namespace std::chrono;





int main() {


   int arr[400000] = {};
    int count = 0;

    // for (int j = 0; j<20000;j++)
    //         arr[j] = j;

   int *ptr = &arr[0];

   int *ptr_temp = &arr[0];

   cout<<"The values in the array are: ";
    int i = 0; 

    int size = sizeof(int);


   while(i < 400000) 
   {

    auto start = high_resolution_clock::now();
      cout<< *ptr << " ";
       
    auto middle = high_resolution_clock::now();

      ptr = ptr + 32010;

      //cout<< ptr <<" "<< endl;
    auto end = high_resolution_clock::now();


    i=i+32010;


    auto duration1 = duration_cast<milliseconds>(middle - start);

        //cout << "size " << size<< endl;
        //size = size + (2000* sizeof(int));


    auto duration = duration_cast<milliseconds>(end - middle);
 
    //cout << duration1.count() <<" "<< duration.count() << " seconds" << endl;

    int *x = &arr[0];

    //cout<<x<<" "<<ptr<<" "<<&arr[0]<<endl;

    count++;
    int block = 1;
    while(x<ptr)
    {

        auto start = high_resolution_clock::now();
        cout<< x  << " " << *x << endl; 
        auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);
 
    cout << "Latency of "<< duration.count() << " milliseconds " << " to access block " << block << " in set " <<count <<endl;

        block++;
        x = x + 32010;

    }


   }
   return 0;
}